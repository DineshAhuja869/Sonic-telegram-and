from web3 import Web3
from eth_account import Account
import secrets
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class WalletManager:
    def __init__(self):
        self._wallets = {}  # Store wallet addresses
        self._private_keys = {}  # Store private keys
        self._connect_to_rpc()

    def _connect_to_rpc(self):
        """Connect to Sonic Network RPC with retry logic."""
        max_retries = 3
        retry_count = 0

        while retry_count < max_retries:
            try:
                self.w3 = Web3(Web3.HTTPProvider('https://rpc.soniclabs.com'))
                if self.w3.is_connected():
                    logger.info("Connected to Sonic Network RPC")
                    return True
                raise Exception("Could not connect to RPC")
            except Exception as e:
                retry_count += 1
                logger.warning(f"RPC connection attempt {retry_count} failed: {e}")
                if retry_count == max_retries:
                    logger.error("Failed to connect to RPC after maximum retries")
                    self.w3 = None
                    return False

    def is_valid_private_key(self, private_key: str) -> bool:
        """Validate private key format and content."""
        try:
            # Remove '0x' prefix if present
            private_key = private_key.replace('0x', '')

            # Check length (32 bytes = 64 hex chars)
            if len(private_key) != 64:
                logger.error("Invalid private key length")
                return False

            # Check if valid hex
            try:
                int(private_key, 16)
            except ValueError:
                logger.error("Invalid hex format in private key")
                return False

            # Additional validation: ensure it's not all zeros
            if int(private_key, 16) == 0:
                logger.error("Invalid private key: all zeros")
                return False

            return True
        except Exception as e:
            logger.error(f"Error validating private key: {e}")
            return False

    def connect_wallet(self, private_key: str) -> str:
        """Connect a wallet using a private key with validation."""
        try:
            # Remove '0x' prefix if present and validate private key
            private_key = private_key.replace('0x', '')
            if not self.is_valid_private_key(private_key):
                logger.error("Invalid private key format")
                return ''

            # Add 0x prefix for Account creation
            full_private_key = '0x' + private_key
            account = Account.from_key(full_private_key)
            address = account.address

            # Store wallet info
            self._wallets[address] = 0.0  # Initialize with 0 balance
            self._private_keys[address] = private_key
            logger.info(f"Wallet connected successfully: {address}")
            return address
        except Exception as e:
            logger.error(f"Error connecting wallet: {e}")
            return ''

    def is_valid_address(self, address: str) -> bool:
        """Validate if a string is a valid Ethereum address."""
        try:
            if not self.w3:
                if not self._connect_to_rpc():
                    return False
            return self.w3.is_address(address) and address.startswith('0x')
        except Exception as e:
            logger.error(f"Error validating address: {e}")
            return False

    def get_balance(self, address: str) -> float:
        """Get balance for a wallet address with enhanced error handling."""
        try:
            if not self.w3 or not self.w3.is_connected():
                if not self._connect_to_rpc():
                    logger.error("Could not connect to RPC")
                    return 0.0

            if not self.is_valid_address(address):
                logger.error(f"Invalid address format: {address}")
                return 0.0

            balance_wei = self.w3.eth.get_balance(address)
            balance_eth = self.w3.from_wei(balance_wei, 'ether')
            logger.info(f"Balance fetched for {address}: {balance_eth}")
            return float(balance_eth)
        except Exception as e:
            logger.error(f"Error fetching balance: {e}")
            return 0.0

    def get_token_details(self, token_address: str) -> dict:
        """Get token details from the contract."""
        try:
            if not self.w3 or not self.w3.is_connected():
                if not self._connect_to_rpc():
                    return {"error": "Failed to connect to RPC"}

            if not self.is_valid_address(token_address):
                return {"error": "Invalid token address"}

            # ERC20 ABI for name, symbol, and decimals
            abi = [
                {"constant":True,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"type":"function"},
                {"constant":True,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"type":"function"},
                {"constant":True,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"type":"function"}
            ]

            token_contract = self.w3.eth.contract(address=self.w3.to_checksum_address(token_address), abi=abi)

            return {
                "name": token_contract.functions.name().call(),
                "symbol": token_contract.functions.symbol().call(),
                "decimals": token_contract.functions.decimals().call(),
                "address": token_address
            }
        except Exception as e:
            logger.error(f"Error getting token details: {e}")
            return {"error": f"Failed to get token details: {str(e)}"}

    def _encode_approve_function(self, token_address: str, spender_address: str, amount: int) -> str:
        """Encode the approve function call."""
        try:
            logger.info(f"=== Encoding approve function ===")
            logger.info(f"Token: {token_address}")
            logger.info(f"Spender: {spender_address}")
            logger.info(f"Amount: {amount}")

            # Method ID for approve(address,uint256)
            method_id = '0x095ea7b3'

            # Remove '0x' prefix if present for spender address
            clean_address = spender_address.replace('0x', '')

            # Pad parameters to 32 bytes each
            spender_param = clean_address.rjust(64, '0')
            amount_param = hex(amount)[2:].rjust(64, '0')

            # Combine all parameters
            data = method_id + spender_param + amount_param

            logger.info(f"=== Final Encoded Data ===")
            logger.info(f"Method ID: {method_id}")
            logger.info(f"Complete data: {data}")
            return data

        except Exception as e:
            logger.error(f"Error encoding approve function: {e}")
            raise ValueError(f"Failed to encode approve function: {str(e)}")

    def _encode_sell_function(self, token_address: str, amount: int, min_amount: int, deadline: int) -> str:
        """Encode the sell function call."""
        try:
            logger.info(f"=== Encoding sell function ===")
            logger.info(f"Token: {token_address}")
            logger.info(f"Amount: {amount}")
            logger.info(f"Min Amount: {min_amount}")
            logger.info(f"Deadline: {deadline}")

            # Method ID for sell(address,uint256,uint256,uint256)
            method_id = '0x92cdbac5'

            # Remove '0x' prefix if present for token address
            clean_address = token_address.replace('0x', '')

            # Pad parameters to 32 bytes each
            token_param = clean_address.rjust(64, '0')
            amount_param = hex(amount)[2:].rjust(64, '0')
            min_param = hex(min_amount)[2:].rjust(64, '0')
            deadline_param = hex(deadline)[2:].rjust(64, '0')

            # Combine all parameters
            data = method_id + token_param + amount_param + min_param + deadline_param

            logger.info(f"=== Final Encoded Data ===")
            logger.info(f"Method ID: {method_id}")
            logger.info(f"Complete data: {data}")
            return data

        except Exception as e:
            logger.error(f"Error encoding sell function: {e}")
            raise ValueError(f"Failed to encode sell function: {str(e)}")

    def _send_approve_transaction(self, wallet_address: str, token_address: str, spender_address: str, private_key: str) -> tuple[bool, str]:
        """Send an approve transaction with high gas price for faster execution."""
        try:
            logger.info(f"=== Sending approve transaction ===")
            # Maximum uint256 value for unlimited approval
            max_amount = 2**256 - 1

            # Encode approve function
            approve_data = self._encode_approve_function(token_address, spender_address, max_amount)

            # Get current gas price and increase it for faster execution
            base_gas_price = self.w3.eth.gas_price
            gas_price = int(base_gas_price * 1.2)  # 20% higher than base price
            logger.info(f"Using gas price: {gas_price} (120% of base: {base_gas_price})")

            # Get nonce
            nonce = self.w3.eth.get_transaction_count(wallet_address)

            # Build approve transaction
            transaction = {
                'from': wallet_address,
                'to': token_address,
                'value': 0,
                'nonce': nonce,
                'gas': 200000,  # Standard gas limit for approve
                'gasPrice': gas_price,
                'data': approve_data,
                'chainId': self.w3.eth.chain_id
            }

            # Sign and send transaction
            signed_txn = self.w3.eth.account.sign_transaction(
                transaction,
                private_key='0x' + private_key
            )
            tx_hash = self.w3.eth.send_raw_transaction(signed_txn.raw_transaction)

            # Wait for the approval to be mined
            receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash, timeout=180)
            logger.info(f"Approve transaction status: {receipt['status']}")

            if receipt['status'] == 1:
                return True, tx_hash.hex()
            else:
                return False, "Approve transaction failed"

        except Exception as e:
            logger.error(f"Error in approve transaction: {e}")
            return False, f"Approve failed: {str(e)}"

    def process_sell_transaction(self, wallet_address: str, token_address: str, percentage: float) -> tuple[bool, str]:
        """Process sell transaction with separate approve and sell steps."""
        logger.info(f"=== Starting sell process ===")
        logger.info(f"Wallet: {wallet_address}")
        logger.info(f"Token: {token_address}")
        logger.info(f"Percentage to sell: {percentage}%")

        if not self.w3 or not self.w3.is_connected():
            if not self._connect_to_rpc():
                return False, "Failed to establish RPC connection"

        try:
            # Validate addresses
            if not self.is_valid_address(wallet_address):
                return False, "Invalid wallet address"

            if not self.is_valid_address(token_address):
                return False, "Invalid token address"

            # Get private key
            private_key = self._private_keys.get(wallet_address)
            if not private_key:
                return False, "Wallet not found in storage"

            # Calculate sell amount
            token_balance = self.get_token_balance(wallet_address, token_address)
            if token_balance <= 0:
                return False, "Insufficient token balance"

            # Get token details
            token_details = self.get_token_details(token_address)
            if 'error' in token_details:
                return False, f"Failed to get token details: {token_details['error']}"

            decimals = token_details.get('decimals', 18)
            balance_in_wei = int(token_balance * (10 ** decimals))
            sell_amount = int(balance_in_wei * (percentage / 100))
            min_amount = 1  # Minimum possible amount

            if sell_amount <= 0:
                return False, "Calculated sell amount is zero"

            # Router address
            router_address = self.w3.to_checksum_address('0xe220E8d200d3e433b8CFa06397275C03994A5123')

            # First send approve transaction
            approve_success, approve_result = self._send_approve_transaction(
                wallet_address, token_address, router_address, private_key
            )

            if not approve_success:
                return False, f"Approval failed: {approve_result}"

            logger.info("Approval successful, proceeding with sell transaction")

            try:
                # Get current gas price and increase it for faster execution
                base_gas_price = self.w3.eth.gas_price
                gas_price = int(base_gas_price * 1.2)  # 20% higher than base price
                nonce = self.w3.eth.get_transaction_count(wallet_address)
                deadline = int(datetime.now().timestamp()) + 600

                # Encode sell function
                sell_data = self._encode_sell_function(token_address, sell_amount, min_amount, deadline)

                # Build sell transaction
                transaction = {
                    'from': wallet_address,
                    'to': router_address,
                    'value': 0,
                    'nonce': nonce,
                    'gas': 300000,
                    'gasPrice': gas_price,
                    'data': sell_data,
                    'chainId': self.w3.eth.chain_id
                }

                # Sign and send sell transaction
                signed_txn = self.w3.eth.account.sign_transaction(
                    transaction,
                    private_key='0x' + private_key
                )
                tx_hash = self.w3.eth.send_raw_transaction(signed_txn.raw_transaction)

                # Wait for the sell transaction to be mined
                receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash, timeout=180)

                if receipt['status'] == 1:
                    return True, tx_hash.hex()
                else:
                    return False, "Sell transaction failed"

            except Exception as e:
                logger.error(f"Error in sell transaction: {e}")
                return False, f"Sell failed: {str(e)}"

        except Exception as e:
            logger.error(f"Unexpected error in sell process: {str(e)}")
            return False, f"Unexpected error: {str(e)}"

    def get_token_balance(self, wallet_address: str, token_address: str) -> float:
        """Get token balance for a wallet address."""
        try:
            if not self.w3 or not self.w3.is_connected():
                if not self._connect_to_rpc():
                    return 0.0

            if not self.is_valid_address(token_address) or not self.is_valid_address(wallet_address):
                return 0.0

            # ERC20 ABI for balanceOf
            abi = [{"constant":True,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"type":"function"}]

            token_contract = self.w3.eth.contract(address=self.w3.to_checksum_address(token_address), abi=abi)
            balance = token_contract.functions.balanceOf(wallet_address).call()

            # Get token decimals
            token_details = self.get_token_details(token_address)
            decimals = token_details.get('decimals', 18)

            return float(balance) / (10 ** decimals)
        except Exception as e:
            logger.error(f"Error getting token balance: {e}")
            return 0.0

    def _encode_buy_function(self, token_address: str, amount: int, min_amount: int, deadline: int) -> str:
        """Encode the buy function call with validation."""
        if not self.w3:
            raise ValueError("Web3 connection not established")

        try:
            # Function signature: buy(address token, uint256 min, uint256 deadline)
            function_signature = self.w3.keccak(text='buy(address,uint256,uint256)')[:4].hex()

            # Remove '0x' prefix if present for token address
            clean_address = token_address.replace('0x', '')

            # Pad parameters to 32 bytes each
            token_param = clean_address.rjust(64, '0')
            min_param = hex(min_amount)[2:].rjust(64, '0')
            deadline_param = hex(deadline)[2:].rjust(64, '0')

            # Combine all parameters
            data = '0x' + function_signature + token_param + min_param + deadline_param
            logger.debug(f"Encoded buy function data: {data}")
            return data
        except Exception as e:
            logger.error(f"Error encoding buy function: {e}")
            raise ValueError(f"Failed to encode transaction data: {str(e)}")

    def process_buy_transaction(self, wallet_address: str, token_address: str, amount: float) -> tuple[bool, str]:
        """Send a buy transaction with enhanced validation and error handling."""
        logger.info(f"=== Starting buy transaction ===")
        logger.info(f"Wallet: {wallet_address}")
        logger.info(f"Token: {token_address}")
        logger.info(f"Amount: {amount}")

        if not self.w3 or not self.w3.is_connected():
            if not self._connect_to_rpc():
                return False, "Failed to establish RPC connection"

        try:
            # Validate addresses
            if not self.is_valid_address(wallet_address):
                return False, f"Invalid wallet address: {wallet_address}"

            if not self.is_valid_address(token_address):
                return False, f"Invalid token address: {token_address}"

            # Get and validate private key
            private_key = self._private_keys.get(wallet_address)
            if not private_key:
                return False, "Wallet not found in storage"

            try:
                # Convert amount to wei with validation
                if amount <= 0:
                    return False, "Amount must be greater than 0"
                amount_wei = self.w3.to_wei(amount, 'ether')
                logger.info(f"Amount in wei: {amount_wei}")
            except ValueError as ve:
                return False, f"Invalid amount: {str(ve)}"

            # Calculate deadline
            deadline = int(datetime.now().timestamp()) + 600
            logger.info(f"Transaction deadline: {deadline}")

            try:
                # Encode transaction data
                data = self._encode_buy_function(token_address, amount_wei, amount_wei, deadline)
                logger.info("Buy function encoded successfully")

                # Get gas price with retry and increase for faster execution
                try:
                    base_gas_price = self.w3.eth.gas_price
                    gas_price = int(base_gas_price * 1.2)  # 20% higher than base price
                    logger.info(f"Using gas price: {gas_price} (120% of base: {base_gas_price})")
                except Exception as e:
                    logger.error(f"Failed to get gas price: {e}")
                    return False, "Failed to estimate gas price"

                # Get nonce
                try:
                    nonce = self.w3.eth.get_transaction_count(wallet_address)
                    logger.info(f"Transaction nonce: {nonce}")
                except Exception as e:
                    logger.error(f"Failed to get nonce: {e}")
                    return False, "Failed to get transaction count"

                # Router address
                router_address = self.w3.to_checksum_address('0xe220E8d200d3e433b8CFa06397275C03994A5123')
                logger.info(f"Router address: {router_address}")

                # Construct transaction
                transaction = {
                    'from': wallet_address,
                    'to': router_address,
                    'value': amount_wei,
                    'data': data,
                    'gas': 300000,  # Estimated gas limit
                    'gasPrice': gas_price,
                    'nonce': nonce,
                    'chainId': self.w3.eth.chain_id
                }
                logger.info("Transaction constructed successfully")

                # Sign and send transaction
                try:
                    signed_txn = self.w3.eth.account.sign_transaction(
                        transaction, private_key='0x' + private_key
                    )
                    logger.info("Transaction signed successfully")

                    tx_hash = self.w3.eth.send_raw_transaction(signed_txn.raw_transaction)
                    logger.info(f"Buy transaction sent successfully: {tx_hash.hex()}")
                    return True, tx_hash.hex()
                except Exception as e:
                    logger.error(f"Transaction signing/sending failed: {e}")
                    return False, f"Transaction failed: {str(e)}"

            except ValueError as ve:
                logger.error(f"Error preparing transaction: {ve}")
                return False, f"Transaction preparation failed: {str(ve)}"

        except Exception as e:
            logger.error(f"Unexpected error in process_buy_transaction: {e}")
            return False, f"Unexpected error: {str(e)}"