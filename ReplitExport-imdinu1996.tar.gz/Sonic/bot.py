import os
import logging
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
    ContextTypes
)
from keyboard import get_main_menu_keyboard, get_buy_amount_keyboard, get_sell_amount_keyboard
from wallet import WalletManager
from session import SessionManager
import asyncio
from telegram.error import NetworkError, Conflict, RetryAfter
import backoff

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize managers
session_manager = SessionManager()
wallet_manager = WalletManager()

# Get bot token from environment variable
BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
if not BOT_TOKEN:
    raise ValueError("No TELEGRAM_BOT_TOKEN found in environment variables!")

# States
WAITING_FOR_PRIVATE_KEY = "WAITING_FOR_KEY"
WAITING_FOR_TOKEN_ADDRESS = "WAITING_FOR_TOKEN"
WAITING_FOR_CUSTOM_AMOUNT = "WAITING_FOR_AMOUNT"
WAITING_FOR_SELL_TOKEN_ADDRESS = "WAITING_FOR_SELL_TOKEN"
WAITING_FOR_CUSTOM_SELL_AMOUNT = "WAITING_FOR_SELL_AMOUNT"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /start is issued."""
    user_id = str(update.effective_user.id)
    keyboard = get_main_menu_keyboard(user_id)
    await update.message.reply_text(
        'Welcome to the Crypto Wallet Bot! 🚀\n'
        'Please select an option:',
        reply_markup=keyboard
    )

async def handle_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle text input based on current state."""
    user_id = str(update.effective_user.id)
    user_data = context.user_data

    if user_data.get('waiting_for_key') == True:
        await handle_private_key(update, context)
        return

    if user_data.get('waiting_for_token') == True:
        await handle_token_address(update, context)
        return

    if user_data.get('waiting_for_custom_amount') == True:
        await handle_custom_amount(update, context)
        return

    if user_data.get('waiting_for_sell_token') == True:
        await handle_sell_token_address(update, context)
        return

    if user_data.get('waiting_for_custom_sell_amount') == True:
        await handle_custom_sell_amount(update, context)
        return

    # Default response
    keyboard = get_main_menu_keyboard(user_id)
    await update.message.reply_text(
        'Please select an option:',
        reply_markup=keyboard
    )

async def handle_private_key(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle private key input."""
    user_id = str(update.effective_user.id)
    user_data = context.user_data
    user_data['waiting_for_key'] = False
    original_message_id = user_data.get('original_connect_message_id')

    private_key = update.message.text

    # Delete the message containing the private key for security
    try:
        await update.message.delete()
    except Exception as e:
        logger.warning(f"Could not delete message containing private key: {e}")

    # First validate the private key format
    if not wallet_manager.is_valid_private_key(private_key):
        if original_message_id:
            try:
                await context.bot.edit_message_text(
                    chat_id=update.effective_chat.id,
                    message_id=original_message_id,
                    text="❌ Invalid private key format\. Please try again\.",
                    parse_mode='MarkdownV2',
                    reply_markup=get_main_menu_keyboard(user_id)
                )
            except Exception as e:
                logger.error(f"Failed to edit message: {e}")
        return

    # Try to connect the wallet
    wallet_address = wallet_manager.connect_wallet(private_key)
    if wallet_address:
        session_manager.connect_wallet(user_id, wallet_address)

        # Get wallet balance
        balance = wallet_manager.get_balance(wallet_address)

        # Format the address and balance for display
        escaped_address = wallet_address.replace('-', '\\-').replace('.', '\\.').replace('_', '\\_')
        escaped_balance = str(balance).replace('-', '\\-').replace('.', '\\.').replace('_', '\\_')

        # Create a dashboard-like display
        dashboard_text = (
            "✅ *Wallet Connected Successfully\\!*\n\n"
            "*Wallet Dashboard*\n"
            "━━━━━━━━━━━━━━━\n"
            f"📍 *Address:*\n`{escaped_address}`\n\n"
            f"💰 *Balance:* `{escaped_balance} S`\n"
            "━━━━━━━━━━━━━━━\n\n"
            "_Click addresses/amounts to copy_"
        )

        # Edit the original connection message with dashboard
        if original_message_id:
            try:
                await context.bot.edit_message_text(
                    chat_id=update.effective_chat.id,
                    message_id=original_message_id,
                    text=dashboard_text,
                    parse_mode='MarkdownV2',
                    reply_markup=get_main_menu_keyboard(user_id)
                )
            except Exception as e:
                logger.error(f"Failed to edit message: {e}")
    else:
        # Edit the original connection message with error
        if original_message_id:
            try:
                await context.bot.edit_message_text(
                    chat_id=update.effective_chat.id,
                    message_id=original_message_id,
                    text="❌ Error connecting wallet\. Please try again\.",
                    parse_mode='MarkdownV2',
                    reply_markup=get_main_menu_keyboard(user_id)
                )
            except Exception as e:
                logger.error(f"Failed to edit message: {e}")

async def handle_token_address(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle token address input and show buy options."""
    user_id = str(update.effective_user.id)
    user_data = context.user_data
    user_data['waiting_for_token'] = False

    token_address = update.message.text.strip()
    logger.debug(f"Received token address: {token_address}")

    # Validate token address
    if not wallet_manager.is_valid_address(token_address):
        logger.warning(f"Invalid token address format: {token_address}")
        await update.message.reply_text(
            "❌ Invalid token address format\. Please try again\.",
            parse_mode='MarkdownV2',
            reply_markup=get_main_menu_keyboard(user_id)
        )
        return

    # Get token details
    token_details = wallet_manager.get_token_details(token_address)
    logger.debug(f"Token details: {token_details}")

    if 'error' in token_details:
        logger.error(f"Error getting token details: {token_details['error']}")
        await update.message.reply_text(
            f"❌ Error: {token_details['error']}\. Please try again\.",
            parse_mode='MarkdownV2',
            reply_markup=get_main_menu_keyboard(user_id)
        )
        return

    # Store token address for later use
    user_data['token_address'] = token_address
    logger.debug(f"Stored token address for user {user_id}: {token_address}")

    # Show buy options with token details
    keyboard = get_buy_amount_keyboard(token_details)
    await update.message.reply_text(
        f"Token Details:\n"
        f"Name: {token_details['name']}\n"
        f"Symbol: {token_details['symbol']}\n\n"
        f"Select the amount you want to buy:",
        reply_markup=keyboard
    )

async def handle_custom_amount(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle custom amount input."""
    user_id = str(update.effective_user.id)
    user_data = context.user_data
    user_data['waiting_for_custom_amount'] = False

    try:
        amount = float(update.message.text.strip())
        if amount <= 0:
            raise ValueError("Amount must be greater than 0")

        token_address = user_data.get('token_address')
        if not token_address:
            raise ValueError("Token address not found")

        await process_buy_transaction(update, context, token_address, amount)

    except ValueError as e:
        await update.message.reply_text(
            f"❌ Invalid amount: {str(e)}\. Please try again\.",
            parse_mode='MarkdownV2',
            reply_markup=get_main_menu_keyboard(user_id)
        )

async def process_buy_transaction(update: Update, context: ContextTypes.DEFAULT_TYPE, token_address: str, amount: float):
    """Process the buy transaction."""
    user_id = str(update.effective_user.id)
    wallet_address = session_manager.get_wallet(user_id)

    if not wallet_address:
        await update.message.reply_text(
            "❌ No wallet connected\. Please connect your wallet first\.",
            parse_mode='MarkdownV2',
            reply_markup=get_main_menu_keyboard(user_id)
        )
        return

    success, result = wallet_manager.process_buy_transaction(wallet_address, token_address, amount)

    if success:
        escaped_hash = result.replace('-', '\\-').replace('.', '\\.').replace('_', '\\_')
        await update.message.reply_text(
            f"✅ Transaction sent successfully!\n\n"
            f"Transaction Hash: `{escaped_hash}`\n\n"
            f"_\\(Click to copy\\)_",
            parse_mode='MarkdownV2',
            reply_markup=get_main_menu_keyboard(user_id)
        )
    else:
        await update.message.reply_text(
            f"❌ {result}",
            reply_markup=get_main_menu_keyboard(user_id)
        )

async def handle_sell_token_address(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle token address input for selling and show sell options."""
    user_id = str(update.effective_user.id)
    user_data = context.user_data
    user_data['waiting_for_sell_token'] = False

    token_address = update.message.text.strip()
    logger.info(f"Received sell token address: {token_address}")

    # First check if wallet is connected
    if not session_manager.is_connected(user_id):
        await update.message.reply_text(
            "❌ Please connect your wallet first\!",
            parse_mode='MarkdownV2',
            reply_markup=get_main_menu_keyboard(user_id)
        )
        return

    # Validate token address
    if not wallet_manager.is_valid_address(token_address):
        logger.warning(f"Invalid token address format: {token_address}")
        await update.message.reply_text(
            "❌ Invalid token address format\. Please try again\.",
            parse_mode='MarkdownV2',
            reply_markup=get_main_menu_keyboard(user_id)
        )
        return

    # Get token details and balance
    token_details = wallet_manager.get_token_details(token_address)
    logger.debug(f"Token details for sell: {token_details}")

    if 'error' in token_details:
        logger.error(f"Error getting token details: {token_details['error']}")
        await update.message.reply_text(
            f"❌ Error: {token_details['error']}\. Please try again\.",
            parse_mode='MarkdownV2',
            reply_markup=get_main_menu_keyboard(user_id)
        )
        return

    # Get wallet address and token balance
    wallet_address = session_manager.get_wallet(user_id)
    token_balance = wallet_manager.get_token_balance(wallet_address, token_address)
    logger.info(f"Token balance for {token_address}: {token_balance}")

    if token_balance <= 0:
        await update.message.reply_text(
            "❌ You don't have any tokens to sell\!",
            parse_mode='MarkdownV2',
            reply_markup=get_main_menu_keyboard(user_id)
        )
        return

    # Store token address and balance for later use
    user_data['sell_token_address'] = token_address
    user_data['token_balance'] = token_balance
    logger.debug(f"Stored sell token info for user {user_id}: {token_address}, balance: {token_balance}")

    # Show sell options with token details and balance
    keyboard = get_sell_amount_keyboard(token_details, token_balance)
    await update.message.reply_text(
        f"Token Details:\n"
        f"Name: {token_details['name']}\n"
        f"Symbol: {token_details['symbol']}\n"
        f"Your Balance: {token_balance:.6f} {token_details['symbol']}\n\n"
        f"Select the percentage to sell:",
        reply_markup=keyboard
    )

async def handle_custom_sell_amount(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle custom sell amount input."""
    user_id = str(update.effective_user.id)
    user_data = context.user_data
    user_data['waiting_for_custom_sell_amount'] = False

    try:
        token_balance = user_data.get('token_balance', 0)
        percentage = float(update.message.text.strip())

        if percentage <= 0 or percentage > 100:
            raise ValueError("Percentage must be between 0 and 100")

        token_address = user_data.get('sell_token_address')
        if not token_address:
            raise ValueError("Token address not found")

        await process_sell_transaction(update, context, token_address, percentage)

    except ValueError as e:
        await update.message.reply_text(
            f"❌ Invalid percentage: {str(e)}\. Please try again\.",
            parse_mode='MarkdownV2',
            reply_markup=get_main_menu_keyboard(user_id)
        )

async def process_sell_transaction(update: Update, context: ContextTypes.DEFAULT_TYPE, token_address: str, percentage: float):
    """Process the sell transaction."""
    user_id = str(update.effective_user.id)
    wallet_address = session_manager.get_wallet(user_id)
    logger.info(f"Processing sell transaction for user {user_id}, token {token_address}")

    # Check if wallet is connected
    if not wallet_address:
        logger.error(f"No wallet connected for user {user_id}")
        await update.callback_query.edit_message_text(
            "❌ No wallet connected\. Please connect your wallet first\.",
            parse_mode='MarkdownV2',
            reply_markup=get_main_menu_keyboard(user_id)
        )
        return

    try:
        # Show processing message
        await update.callback_query.edit_message_text(
            "⚡ Processing Ultra\\-Fast Sell Transaction\\.\\.\\.\n"
            "✨ Using 5x gas price for instant execution\n"
            "🔄 Pre\\-signing transactions\n"
            "⚡ Sending approve \\+ sell together\n"
            "Please wait a moment\\.\\.\\.",
            parse_mode='MarkdownV2'
        )

        # Process transaction
        success, result = wallet_manager.process_sell_transaction(wallet_address, token_address, percentage)
        logger.info(f"Sell transaction result - Success: {success}, Result: {result}")

        if success:
            escaped_hash = result.replace('-', '\\-').replace('.', '\\.').replace('_', '\\_')
            await update.callback_query.edit_message_text(
                f"✅ Transactions sent successfully\\!\n\n"
                f"💰 Amount: {percentage}% of your tokens\n"
                f"📝 Transaction Hash: `{escaped_hash}`\n\n"
                f"_\\(Click to copy\\)_\n\n"
                f"⏳ Finalizing\\.\\.\\.",
                parse_mode='MarkdownV2',
                reply_markup=get_main_menu_keyboard(user_id)
            )
        else:
            error_msg = result.replace('-', '\\-').replace('.', '\\.').replace('_', '\\_')
            logger.error(f"Sell transaction failed: {result}")
            await update.callback_query.edit_message_text(
                f"❌ Transaction failed:\n{error_msg}",
                parse_mode='MarkdownV2',
                reply_markup=get_main_menu_keyboard(user_id)
            )
    except Exception as e:
        logger.error(f"Error in process_sell_transaction: {str(e)}", exc_info=True)
        try:
            await update.callback_query.edit_message_text(
                "❌ An error occurred while processing the transaction\\.\n"
                "Please check if you have enough balance and try again\\.",
                parse_mode='MarkdownV2',
                reply_markup=get_main_menu_keyboard(user_id)
            )
        except Exception as msg_e:
            logger.error(f"Failed to send error message: {msg_e}")

async def button_click(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle button clicks."""
    query = update.callback_query
    await query.answer()

    user_id = str(update.effective_user.id)
    action = query.data
    logger.debug(f"Button click action: {action} from user {user_id}")

    if action == "enter_sell_token_address":
        context.user_data['waiting_for_sell_token'] = True
        logger.debug(f"User {user_id} entering sell token address state")
        await query.edit_message_text(
            "Please send the token address you want to sell\.\n\n"
            "Format: `0x...`",
            parse_mode='MarkdownV2'
        )

    elif action in ['sell_50', 'sell_95', 'sell_100']:
        percentage = float(action.split('_')[1])
        # Convert 95 to 99.97 for faster selling
        if percentage == 95:
            percentage = 99.97
        token_address = context.user_data.get('sell_token_address')
        logger.debug(f"Processing sell percentage: {percentage}% for token {token_address}")
        if token_address:
            await process_sell_transaction(update, context, token_address, percentage)
        else:
            logger.error(f"Token address not found for user {user_id}")
            await query.edit_message_text(
                "❌ Token address not found\. Please try again\.",
                parse_mode='MarkdownV2',
                reply_markup=get_main_menu_keyboard(user_id)
            )

    elif action == 'sell_custom':
        context.user_data['waiting_for_custom_sell_amount'] = True
        logger.debug(f"User {user_id} entering custom sell amount state")
        await query.edit_message_text(
            "Please enter the percentage you want to sell \\(1\-100\\)\.\n\n"
            "Example: `50` for 50%",
            parse_mode='MarkdownV2'
        )

    elif action == 'none':
        return

    elif action == "enter_token_address":
        context.user_data['waiting_for_token'] = True
        logger.debug(f"User {user_id} entering token address state")
        await query.edit_message_text(
            "Please send the token address you want to buy\.\n\n"
            "Format: `0x...`",
            parse_mode='MarkdownV2'
        )

    elif action in ['buy_10', 'buy_20']:
        amount = float(action.split('_')[1])
        token_address = context.user_data.get('token_address')
        logger.debug(f"Processing preset buy amount: {amount} for token {token_address}")
        if token_address:
            await process_buy_transaction(update, context, token_address, amount)
        else:
            logger.error(f"Token address not found for user {user_id}")
            await query.edit_message_text(
                "❌ Token address not found\. Please try again\.",
                parse_mode='MarkdownV2',
                reply_markup=get_main_menu_keyboard(user_id)
            )

    elif action == 'buy_custom':
        context.user_data['waiting_for_custom_amount'] = True
        logger.debug(f"User {user_id} entering custom amount state")
        await query.edit_message_text(
            "Please enter the amount you want to buy\.\n\n"
            "Format: `10.5`",
            parse_mode='MarkdownV2'
        )

    elif action == 'back_to_main':
        # Clear stored token address
        if 'token_address' in context.user_data:
            del context.user_data['token_address']
        if 'sell_token_address' in context.user_data:
            del context.user_data['sell_token_address']
        if 'token_balance' in context.user_data:
            del context.user_data['token_balance']
        await query.edit_message_text(
            "Main Menu:",
            reply_markup=get_main_menu_keyboard(user_id)
        )

    elif action == "connect_wallet":
        if not session_manager.is_connected(user_id):
            context.user_data['waiting_for_key'] = True
            # Store the message ID for later reference
            context.user_data['original_connect_message_id'] = query.message.message_id
            await query.message.edit_text(
                "Please send me your private key\. This will be used to connect to your wallet\.\n\n"
                "⚠️ Never share your private key with anyone else\!\n"
                "⚠️ This bot stores your key securely in memory\.",
                parse_mode='MarkdownV2'
            )
        else:
            await query.message.edit_text(
                "You already have a connected wallet\!\n"
                "Please disconnect the current wallet first\.",
                parse_mode='MarkdownV2',
                reply_markup=get_main_menu_keyboard(user_id)
            )

    elif action == "show_private_key":
        if session_manager.is_connected(user_id):
            wallet_address = session_manager.get_wallet(user_id)
            escaped_address = wallet_address.replace('-', '\\-').replace('.', '\\.').replace('_', '\\_')
            await query.edit_message_text(
                f"Your wallet address:\n`{escaped_address}`\n\n"
                f"_\\(Click to copy\\)_",
                parse_mode='MarkdownV2',
                reply_markup=get_main_menu_keyboard(user_id)
            )
        else:
            await query.edit_message_text(
                "Please connect your wallet first\!",
                parse_mode='MarkdownV2',
                reply_markup=get_main_menu_keyboard(user_id)
            )

    elif action == "check_balance":
        if session_manager.is_connected(user_id):
            wallet_address = session_manager.get_wallet(user_id)
            balance = wallet_manager.get_balance(wallet_address)
            escaped_address = wallet_address.replace('-', '\\-').replace('.', '\\.').replace('_', '\\_')
            await query.edit_message_text(
                f"Your wallet:\n`{escaped_address}`\n\n"
                f"Balance: `{balance}` S\n\n"
                f"_\\(Click to copy\\)_",
                parse_mode='MarkdownV2',
                reply_markup=get_main_menu_keyboard(user_id)
            )
        else:
            await query.edit_message_text(
                "Please connect your wallet first\!",
                parse_mode='MarkdownV2',
                reply_markup=get_main_menu_keyboard(user_id)
            )

    elif action == "disconnect_wallet":
        if session_manager.is_connected(user_id):
            session_manager.disconnect_wallet(user_id)
            await query.edit_message_text(
                "Wallet disconnected successfully\!",
                parse_mode='MarkdownV2',
                reply_markup=get_main_menu_keyboard(user_id)
            )
        else:
            await query.edit_message_text(
                "No wallet connected\!",
                parse_mode='MarkdownV2',
                reply_markup=get_main_menu_keyboard(user_id)
            )


def main() -> None:
    """Start the bot."""
    application = Application.builder().token(BOT_TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(button_click))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_input))

    # Add error handler for common issues
    async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle errors caused by updates."""
        error = context.error
        logger.error(f"Exception while handling an update: {error}")

        if isinstance(error, Conflict):
            logger.warning("Conflict detected, waiting before retry...")
            await asyncio.sleep(5)  # Wait 5 seconds before retry
        elif isinstance(error, NetworkError):
            logger.warning("Network error occurred, retrying...")
            await asyncio.sleep(1)  # Wait 1 second before retry
        elif isinstance(error, RetryAfter):
            logger.warning(f"Rate limit hit. Waiting {error.retry_after} seconds")
            await asyncio.sleep(error.retry_after)

    application.add_error_handler(error_handler)

    print("Bot started...")

    # Use exponential backoff for the polling mechanism
    @backoff.on_exception(backoff.expo,
                         (NetworkError, Conflict),
                         max_tries=5,
                         max_time=300)
    def run_polling():
        application.run_polling(drop_pending_updates=True)

    run_polling()

if __name__ == '__main__':
    main()