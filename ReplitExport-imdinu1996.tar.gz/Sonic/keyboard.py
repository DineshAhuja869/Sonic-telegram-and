from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from session import SessionManager

def get_main_menu_keyboard(user_id: str = None):
    """Create the main menu keyboard."""
    session_manager = SessionManager()

    keyboard = []

    # First row - Connection status
    if user_id and session_manager.is_connected(user_id):
        wallet_address = session_manager.get_wallet(user_id)
        short_address = wallet_address[:6] + '...' + wallet_address[-4:]
        keyboard.append([
            InlineKeyboardButton(f"Connected ✅ ({short_address})", callback_data='none'),
        ])
        # Trading buttons
        keyboard.append([
            InlineKeyboardButton("Buy 💰", callback_data='enter_token_address'),
            InlineKeyboardButton("Sell 💱", callback_data='enter_sell_token_address')
        ])
    else:
        # Show connect button if not connected
        keyboard.append([
            InlineKeyboardButton("Connect Wallet 🔗", callback_data='connect_wallet'),
        ])
        keyboard.append([
            InlineKeyboardButton("Buy 💰", callback_data='enter_token_address'),
            InlineKeyboardButton("Sell 💱", callback_data='enter_sell_token_address')
        ])

    # Second row - Common actions
    keyboard.append([
        InlineKeyboardButton("Show Private Key 🔑", callback_data='show_private_key'),
        InlineKeyboardButton("Check Balance 💎", callback_data='check_balance')
    ])

    # Third row - Disconnect option
    keyboard.append([
        InlineKeyboardButton("Disconnect Wallet ❌", callback_data='disconnect_wallet')
    ])

    return InlineKeyboardMarkup(keyboard)

def get_buy_amount_keyboard(token_details: dict):
    """Create keyboard with preset buy amounts."""
    keyboard = []

    # Show token details
    if 'error' not in token_details:
        name = token_details.get('name', 'Unknown')
        symbol = token_details.get('symbol', 'Unknown')
        keyboard.append([
            InlineKeyboardButton(f"Token: {name} ({symbol})", callback_data='none')
        ])

    # Preset amounts
    keyboard.append([
        InlineKeyboardButton("Buy 10 S 💰", callback_data='buy_10'),
        InlineKeyboardButton("Buy 20 S 💰", callback_data='buy_20')
    ])

    # Custom amount
    keyboard.append([
        InlineKeyboardButton("Custom Amount 💰", callback_data='buy_custom')
    ])

    # Back button
    keyboard.append([
        InlineKeyboardButton("« Back", callback_data='back_to_main')
    ])

    return InlineKeyboardMarkup(keyboard)

def get_sell_amount_keyboard(token_details: dict, token_balance: float = 0):
    """Create keyboard with preset sell percentages."""
    keyboard = []

    # Show token details
    if 'error' not in token_details:
        name = token_details.get('name', 'Unknown')
        symbol = token_details.get('symbol', 'Unknown')
        keyboard.append([
            InlineKeyboardButton(f"Token: {name} ({symbol})", callback_data='none')
        ])
        keyboard.append([
            InlineKeyboardButton(f"Balance: {token_balance} {symbol}", callback_data='none')
        ])

    # Preset percentages
    keyboard.append([
        InlineKeyboardButton("Sell 50% 💱", callback_data='sell_50')
    ])
    keyboard.append([
        InlineKeyboardButton("Sell 99.97% 💱", callback_data='sell_95'),
        InlineKeyboardButton("Sell 100% 💱", callback_data='sell_100')
    ])

    # Custom amount
    keyboard.append([
        InlineKeyboardButton("Custom Amount 💱", callback_data='sell_custom')
    ])

    # Back button
    keyboard.append([
        InlineKeyboardButton("« Back", callback_data='back_to_main')
    ])

    return InlineKeyboardMarkup(keyboard)