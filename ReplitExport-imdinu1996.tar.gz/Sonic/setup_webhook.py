import os
import requests
import logging

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def setup_webhook():
    """Set up webhook for the Telegram bot."""
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not token:
        logger.error("Error: TELEGRAM_BOT_TOKEN not found in environment variables")
        return False

    # Get Vercel URL from environment variable
    vercel_url = os.environ.get("VERCEL_URL")
    if not vercel_url:
        logger.error("Error: VERCEL_URL not found in environment variables")
        return False

    webhook_url = f"{vercel_url}/api/webhook"
    logger.info(f"Setting webhook URL to: {webhook_url}")

    # Telegram Bot API endpoint to set webhook
    api_url = f"https://api.telegram.org/bot{token}/setWebhook"

    try:
        response = requests.post(api_url, json={"url": webhook_url})
        if response.status_code == 200 and response.json().get("ok"):
            logger.info(f"Webhook set successfully to: {webhook_url}")
            return True
        else:
            logger.error(f"Failed to set webhook. Response: {response.json()}")
            return False
    except Exception as e:
        logger.error(f"Error setting webhook: {e}")
        return False

if __name__ == "__main__":
    success = setup_webhook()
    if not success:
        exit(1)