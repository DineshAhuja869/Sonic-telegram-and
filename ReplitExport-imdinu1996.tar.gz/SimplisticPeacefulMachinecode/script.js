// script.js
document.getElementById('app1').addEventListener('click', function() {
    alert('App 1 clicked!');
});

document.getElementById('app2').addEventListener('click', function() {
    alert('App 2 clicked!');
});

document.getElementById('app3').addEventListener('click', function() {
    alert('App 3 clicked!');
});

document.getElementById('app4').addEventListener('click', function() {
    alert('App 4 clicked!');
}); 