      from telethon.sync import TelegramClient
      from telethon.tl.functions.channels import InviteToChannelRequest

      api_id = 25639316
      api_hash = 'aaada27439c7f2c34fd0efa3040c0492'
      source_channel_username = 'pumpfunsupport'  # Replace with your source channel username

      destination_channel_username = 'pppptestpp'  # Replace with your destination channel or group username

      with TelegramClient('session_name', api_id, api_hash) as client:
          # Fetch source channel
          source_channel = client.get_entity(source_channel_username)

          # Fetch source channel members
          source_channel_members = client.get_participants(source_channel)

          # Fetch destination channel or group
          destination_entity = client.get_entity(destination_channel_username)

          # Add source channel members to destination channel or group
          for member in source_channel_members:
              try:
                  client(InviteToChannelRequest(destination_entity, [member]))
                  print(f"Added {member.first_name} to the destination channel/group.")
              except Exception as e:
                  print(f"Failed to add {member.first_name}: {e}")



