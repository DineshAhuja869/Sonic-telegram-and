class SessionManager:
    def __init__(self):
        self._connected_wallets = {}  # Store user_id -> wallet_address mapping

    def connect_wallet(self, user_id: str, wallet_address: str) -> None:
        """Connect a wallet to a user."""
        self._connected_wallets[user_id] = wallet_address

    def disconnect_wallet(self, user_id: str) -> None:
        """Disconnect a user's wallet."""
        self._connected_wallets.pop(user_id, None)

    def is_connected(self, user_id: str) -> bool:
        """Check if a user has a connected wallet."""
        return user_id in self._connected_wallets

    def get_wallet(self, user_id: str) -> str:
        """Get a user's connected wallet address."""
        return self._connected_wallets.get(user_id, '')
