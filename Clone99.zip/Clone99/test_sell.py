import logging
from wallet import WalletManager
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def test_sell_transaction(private_key: str, token_address: str):
    """Test the sell transaction functionality with known valid values."""
    try:
        logger.info("=== Starting sell transaction test ===")

        # Initialize wallet manager
        wallet_manager = WalletManager()
        logger.info("WalletManager initialized")

        # Connect wallet
        wallet_address = wallet_manager.connect_wallet(private_key)
        if not wallet_address:
            logger.error("Failed to connect wallet")
            return False

        logger.info(f"Wallet connected successfully: {wallet_address}")

        # Test with the same percentage as the successful transaction
        percentage = 50.0
        logger.info(f"Testing sell with {percentage}% of token balance")

        success, result = wallet_manager.send_sell_transaction(wallet_address, token_address, percentage)

        if success:
            logger.info(f"Sell transaction successful. Hash: {result}")
            # Verify final balances
            final_token_balance = wallet_manager.get_token_balance(wallet_address, token_address)
            final_native_balance = wallet_manager.get_balance(wallet_address)
            logger.info(f"Final token balance: {final_token_balance}")
            logger.info(f"Final native balance: {final_native_balance}")
            logger.info("=== Test completed successfully ===")
            return True
        else:
            logger.error(f"Sell transaction failed: {result}")
            return False

    except Exception as e:
        logger.error(f"Error in test_sell_transaction: {str(e)}", exc_info=True)
        return False

if __name__ == "__main__":
    logger.info("Starting sell transaction test")

    # Use the successful transaction parameters
    private_key = "336552e7921e9689f379091b8a2c2b5925565a1db42cae99d422a7de28597900"  # Example private key
    test_token = "0x8b74C1C623F1972A035839463051669C735E2BDF"  # Example token address

    if test_sell_transaction(private_key, test_token):
        logger.info("Test completed successfully")
    else:
        logger.error("Test failed")
        exit(1)