from flask import Flask, request, Response
import os
import sys
import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters

# Add parent directory to path so we can import our bot modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from bot import start, button_click, handle_input

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)

# Get bot token
BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
if not BOT_TOKEN:
    raise ValueError("No TELEGRAM_BOT_TOKEN found in environment variables!")

# Initialize bot application
application = Application.builder().token(BOT_TOKEN).build()

# Add handlers
application.add_handler(CommandHandler("start", start))
application.add_handler(CallbackQueryHandler(button_click))
application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_input))

@app.route("/api/webhook", methods=["POST"])
async def webhook():
    """Handle incoming webhook updates from Telegram."""
    try:
        # Get the update data
        update_data = request.get_json()

        if update_data:
            # Create update object
            update = Update.de_json(update_data, application.bot)

            # Process update
            await application.process_update(update)
            return Response(status=200)

        return Response(status=400)
    except Exception as e:
        logger.error(f"Webhook error: {e}", exc_info=True)
        return Response(status=500)

# Health check endpoint
@app.route("/api/health", methods=["GET"])
def health_check():
    """Health check endpoint for Vercel."""
    return {"status": "ok", "timestamp": str(os.path.getmtime(__file__))}

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)